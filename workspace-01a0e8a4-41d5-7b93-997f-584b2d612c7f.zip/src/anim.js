/* ========== Animation gallery ========== */
(function () {
'use strict';
const grid = document.getElementById('grid');
const DPR = Math.min(2, devicePixelRatio || 1);
let speed = 1, playing = true, onion = false, FRAMES = 16;
const cards = [];

const CELL = { w: 180, h: 210, ox: 90, oy: 118 }; // sprite cell + body origin (hip)

function fit(cv, w, h) {
  cv.width = w * DPR; cv.height = h * DPR;
  cv.style.width = w + 'px'; cv.style.height = h + 'px';
  const c = cv.getContext('2d');
  c.setTransform(DPR, 0, 0, DPR, 0, 0);
  return c;
}

function drawFrame(c, name, t, w, h, opt) {
  opt = opt || {};
  const ox = w / 2, oy = h * 0.56;
  if (!opt.noClear) c.clearRect(0, 0, w, h);
  if (opt.bg) {
    const g = c.createLinearGradient(0, 0, 0, h);
    g.addColorStop(0, '#f4f7fc'); g.addColorStop(1, '#dde5f0');
    c.fillStyle = g; c.fillRect(0, 0, w, h);
    // faux wall + holds for context
    c.fillStyle = 'rgba(120,140,170,.16)';
    for (let y = 8; y < h; y += 26) c.fillRect(0, y, w, 1.5);
    c.fillStyle = 'rgba(120,140,170,.22)';
    for (let y = 14; y < h; y += 52) for (let x = 14; x < w; x += 46) { c.beginPath(); c.arc(x, y, 3.5, 0, 7); c.fill(); }
  }
  const pose = STICK.sample(name, t, ox, oy, false);
  STICK.draw(c, pose, { color: opt.color || '#151a24', lineWidth: opt.lw || 4.6, shadow: !!opt.bg });
}

function makeCard(key, title, desc, kind) {
  const el = document.createElement('section');
  el.className = 'card';
  el.innerHTML = `
    <div class="stage"><canvas class="main"></canvas><span class="tag">${key}()</span><span class="kind ${kind === 'loop' ? 'lo' : 'os'}">${kind}</span></div>
    <div class="meta"><h2>${title}</h2><p>${desc}</p></div>
    <input class="scrub" type="range" min="0" max="1000" value="0">
    <canvas class="strip"></canvas>
    <div class="acts">
      <button class="exp">Export sheet</button>
      <button class="cpy ghost">Copy code</button>
      <span class="fc"></span>
    </div>`;
  grid.appendChild(el);
  const main = el.querySelector('.main'), strip = el.querySelector('.strip');
  const mc = fit(main, 260, 250);
  const sc = fit(strip, 260, 62);
  const scrub = el.querySelector('.scrub');
  const card = { key, el, mc, sc, t: Math.random(), scrub, manual: false };

  scrub.addEventListener('input', () => { card.manual = true; card.t = scrub.value / 1000; });
  scrub.addEventListener('change', () => setTimeout(() => card.manual = false, 900));

  el.querySelector('.exp').onclick = () => exportSheet(key);
  el.querySelector('.cpy').onclick = (e) => {
    const src = 'STICK.anims.' + key + ' = ' + STICK.anims[key].toString() + ';';
    navigator.clipboard.writeText(src).then(() => {
      e.target.textContent = 'Copied ✓'; setTimeout(() => e.target.textContent = 'Copy code', 1400);
    }).catch(() => e.target.textContent = 'ctrl+C failed');
  };
  cards.push(card);
  return card;
}

function drawStrip(card) {
  const w = 260, h = 62, n = Math.min(FRAMES, 12);
  const c = card.sc;
  c.clearRect(0, 0, w, h);
  const cw = w / n;
  for (let i = 0; i < n; i++) {
    c.save();
    c.translate(i * cw, 0);
    c.fillStyle = i % 2 ? 'rgba(20,28,44,.05)' : 'rgba(20,28,44,.02)';
    c.fillRect(0, 0, cw, h);
    c.beginPath(); c.rect(0, 0, cw, h); c.clip();
    c.translate(cw / 2, h * 0.52);
    c.scale(0.30, 0.30);
    const pose = STICK.sample(card.key, i / n, 0, 0, false);
    STICK.draw(c, pose, { color: '#5d6b82', lineWidth: 13 });
    c.restore();
  }
}

/* ---- sprite sheet export ---- */
function exportSheet(key) {
  const n = FRAMES, cols = Math.min(8, n), rows = Math.ceil(n / cols);
  const W = CELL.w, H = CELL.h;
  const cv = document.createElement('canvas');
  cv.width = W * cols; cv.height = H * rows;
  const c = cv.getContext('2d');
  for (let i = 0; i < n; i++) {
    const cx = (i % cols) * W, cy = Math.floor(i / cols) * H;
    c.save(); c.translate(cx, cy);
    c.beginPath(); c.rect(0, 0, W, H); c.clip();
    const pose = STICK.sample(key, i / n, CELL.ox, CELL.oy, false);
    STICK.draw(c, pose, { color: '#151a24', lineWidth: 4.6 });
    c.restore();
  }
  const a = document.createElement('a');
  a.download = `stickman_${key}_${n}f_${W}x${H}.png`;
  a.href = cv.toDataURL('image/png');
  a.click();
}

/* ---- build ---- */
STICK.META.forEach(([k, t, d, kind]) => makeCard(k, t, d, kind));

/* ---- controls ---- */
const $ = id => document.getElementById(id);
$('speed').oninput = e => { speed = +e.target.value; $('spv').textContent = speed.toFixed(2) + '×'; };
$('frames').oninput = e => { FRAMES = +e.target.value; $('frv').textContent = FRAMES; cards.forEach(drawStrip); };
$('toggle').onclick = e => { playing = !playing; e.target.textContent = playing ? '⏸ Pause' : '▶ Play'; };
$('onion').onclick = e => { onion = !onion; e.target.textContent = 'Onion skin: ' + (onion ? 'on' : 'off');
  e.target.classList.toggle('ghost', !onion); };

cards.forEach(drawStrip);

let last = performance.now();
function loop(now) {
  const dt = Math.min(0.05, (now - last) / 1000); last = now;
  for (const card of cards) {
    if (playing && !card.manual) {
      card.t = (card.t + dt * 0.55 * speed) % 1;
      card.scrub.value = card.t * 1000;
    }
    drawFrame(card.mc, card.key, card.t, 260, 250, { bg: true });
    if (onion) {
      for (let k = 1; k <= 3; k++) {
        card.mc.globalAlpha = 0.18 - k * 0.04;
        drawFrame(card.mc, card.key, (card.t - k * 0.06 + 1) % 1, 260, 250, { noClear: true, color: '#2b6cb0' });
      }
      card.mc.globalAlpha = 1;
    }
    card.el.querySelector('.fc').textContent = 'frame ' + (Math.floor(card.t * FRAMES) + 1) + '/' + FRAMES;
  }
  requestAnimationFrame(loop);
}
requestAnimationFrame(loop);
})();
