/* ===========================================================
   STICKMAN CLIMBER — skeleton, IK renderer & animation library
   Shared by game.html and animations.html
   =========================================================== */
const STICK = (function () {
  const L = {
    upperArm: 21, foreArm: 22,
    thigh: 22, shin: 23,
    torso: 36, neck: 9, headR: 9,
    shoulder: 11, hipW: 9
  };

  const lerp = (a, b, t) => a + (b - a) * t;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const smooth = t => t * t * (3 - 2 * t);
  // eased 0..1 over a window [s,e] of the cycle
  function win(t, s, e) {
    if (e > 1) { // wrapping window
      let tt = t < s ? t + 1 : t;
      return smooth(clamp((tt - s) / (e - s), 0, 1));
    }
    return smooth(clamp((t - s) / (e - s), 0, 1));
  }

  /* two-bone IK: returns joint (elbow/knee) position */
  function ik(ax, ay, bx, by, l1, l2, sign) {
    let dx = bx - ax, dy = by - ay;
    let d = Math.hypot(dx, dy) || 0.0001;
    const ux = dx / d, uy = dy / d;
    d = clamp(d, Math.abs(l1 - l2) + 0.01, l1 + l2 - 0.01);
    const a = (l1 * l1 - l2 * l2 + d * d) / (2 * d);
    const h = Math.sqrt(Math.max(0, l1 * l1 - a * a));
    const mx = ax + ux * a, my = ay + uy * a;
    return { x: mx + sign * -uy * h, y: my + sign * ux * h,
             ex: ax + ux * d, ey: ay + uy * d };
  }

  /* Build a full pose.
     spec: { hip:{x,y}, lean, hands:[{x,y},{x,y}], feet:[{x,y},{x,y}], headTilt }
     hands/feet are WORLD-space targets (holds the climber is grabbing). */
  function buildPose(spec) {
    const hip = spec.hip;
    const lean = spec.lean || 0;
    const chest = {
      x: hip.x + Math.sin(lean) * L.torso,
      y: hip.y - Math.cos(lean) * L.torso
    };
    const head = {
      x: chest.x + Math.sin(lean + (spec.headTilt || 0)) * (L.neck + L.headR),
      y: chest.y - Math.cos(lean + (spec.headTilt || 0)) * (L.neck + L.headR)
    };
    const px = Math.cos(lean), py = Math.sin(lean); // perpendicular of spine
    const sh = [
      { x: chest.x - px * L.shoulder, y: chest.y - py * L.shoulder },
      { x: chest.x + px * L.shoulder, y: chest.y + py * L.shoulder }
    ];
    const hp = [
      { x: hip.x - px * L.hipW, y: hip.y - py * L.hipW },
      { x: hip.x + px * L.hipW, y: hip.y + py * L.hipW }
    ];
    const elbows = [
      ik(sh[0].x, sh[0].y, spec.hands[0].x, spec.hands[0].y, L.upperArm, L.foreArm, -1),
      ik(sh[1].x, sh[1].y, spec.hands[1].x, spec.hands[1].y, L.upperArm, L.foreArm, 1)
    ];
    const knees = [
      ik(hp[0].x, hp[0].y, spec.feet[0].x, spec.feet[0].y, L.thigh, L.shin, 1),
      ik(hp[1].x, hp[1].y, spec.feet[1].x, spec.feet[1].y, L.thigh, L.shin, -1)
    ];
    // endpoints are clamped to limb length so nothing ever stretches like rubber
    const hands = [{ x: elbows[0].ex, y: elbows[0].ey }, { x: elbows[1].ex, y: elbows[1].ey }];
    const feet  = [{ x: knees[0].ex,  y: knees[0].ey  }, { x: knees[1].ex,  y: knees[1].ey  }];
    return { hip, chest, head, sh, hp, hands, feet, elbows, knees, lean };
  }

  /* Render a pose */
  function draw(ctx, p, opt) {
    opt = opt || {};
    const col = opt.color || '#12151c';
    const lw = opt.lineWidth || 5;
    ctx.save();
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    if (opt.shadow) {
      ctx.shadowColor = 'rgba(0,0,0,.35)';
      ctx.shadowBlur = 8; ctx.shadowOffsetY = 3;
    }
    ctx.strokeStyle = col;
    ctx.fillStyle = col;
    ctx.lineWidth = lw;

    const seg = (a, b) => { ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); };

    // legs (behind)
    ctx.lineWidth = lw * 1.05;
    for (let i = 0; i < 2; i++) {
      seg(p.hp[i], p.knees[i]);
      seg(p.knees[i], p.feet[i]);
    }
    // torso
    ctx.lineWidth = lw * 1.25;
    seg(p.hip, p.chest);
    // shoulders / hips bars
    ctx.lineWidth = lw * 0.9;
    seg(p.sh[0], p.sh[1]);
    seg(p.hp[0], p.hp[1]);
    // arms
    ctx.lineWidth = lw;
    for (let i = 0; i < 2; i++) {
      seg(p.sh[i], p.elbows[i]);
      seg(p.elbows[i], p.hands[i]);
    }
    // hands & feet nubs
    ctx.shadowBlur = 0;
    for (let i = 0; i < 2; i++) {
      ctx.beginPath(); ctx.arc(p.hands[i].x, p.hands[i].y, lw * 0.62, 0, 7); ctx.fill();
      ctx.beginPath(); ctx.arc(p.feet[i].x, p.feet[i].y, lw * 0.66, 0, 7); ctx.fill();
    }
    // head
    ctx.beginPath();
    ctx.arc(p.head.x, p.head.y, L.headR, 0, Math.PI * 2);
    if (opt.hollowHead) { ctx.lineWidth = lw * 0.9; ctx.stroke(); }
    else ctx.fill();
    ctx.restore();
  }

  /* ---------------- Animation library ----------------
     Each animation: fn(t) with t in 0..1 -> pose spec around origin (0,0)
     where (0,0) is the ground-ish reference; the body hangs above it.
     All return { hip, lean, hands, feet, headTilt }                     */

  const P = (x, y) => ({ x, y });

  // Reference rest positions (relative to hip at 0,0)
  const REST = {
    handL: P(-20, -52), handR: P(20, -54),
    footL: P(-15, 40), footR: P(15, 41)
  };

  const anims = {
    /* Hanging idle — slow breathing + sway */
    idle(t) {
      const b = Math.sin(t * Math.PI * 2);
      const s = Math.sin(t * Math.PI * 2 + 1.2);
      return {
        hip: P(s * 2.5, b * 2.2),
        lean: s * 0.05,
        headTilt: -b * 0.06,
        hands: [P(-20, -54 + b * 1.5), P(20, -55 + b * 1.5)],
        feet: [P(-16 + s, 40), P(16 + s, 41)]
      };
    },

    /* Classic 4-beat climb: hand, foot, hand, foot */
    climbUp(t) {
      const H = 46;                  // rise per cycle
      const y = -H * t;              // continuous body rise
      const sway = Math.sin(t * Math.PI * 4) * 3;
      // limb windows
      const lh = win(t, 0.00, 0.22), rf = win(t, 0.22, 0.44),
            rh = win(t, 0.50, 0.72), lf = win(t, 0.72, 0.94);
      const arc = (u, h) => -Math.sin(u * Math.PI) * h;
      return {
        hip: P(sway * 0.5, y),
        lean: sway * 0.012,
        headTilt: -0.12,
        hands: [
          P(-20 + arc(lh, 6), -54 - H * lh + arc(lh, 10)),
          P(20 - arc(rh, 6), -55 - H * rh + arc(rh, 10) + H * 0 - (t < 0.5 ? 0 : 0))
        ].map((p, i) => i === 1 ? P(p.x, p.y - (t >= 0.5 ? 0 : H) * 0 ) : p),
        feet: [
          P(-16, 40 - H * lf + arc(lf, 8)),
          P(16, 41 - H * rf + arc(rf, 8))
        ]
      };
    },

    /* Sideways traverse to the right */
    traverse(t) {
      const D = 40;
      const x = D * t;
      const rh = win(t, 0.00, 0.25), rf = win(t, 0.18, 0.45),
            lh = win(t, 0.50, 0.75), lf = win(t, 0.68, 0.95);
      const arc = (u, h) => -Math.sin(u * Math.PI) * h;
      return {
        hip: P(x, Math.sin(t * Math.PI * 4) * 2),
        lean: 0.08,
        hands: [P(-20 + D * lh + arc(lh, 4), -54 + arc(lh, 9)),
                P(20 + D * rh + arc(rh, 4), -55 + arc(rh, 9))],
        feet: [P(-16 + D * lf, 40 + arc(lf, 7)),
               P(16 + D * rf, 41 + arc(rf, 7))]
      };
    },

    /* Dyno — crouch, explode upward, latch */
    dyno(t) {
      const crouch = t < 0.35 ? smooth(t / 0.35) : 1 - smooth(clamp((t - 0.35) / 0.25, 0, 1));
      const flight = t < 0.35 ? 0 : smooth(clamp((t - 0.35) / 0.45, 0, 1));
      const settle = smooth(clamp((t - 0.8) / 0.2, 0, 1));
      const rise = -70 * flight + 8 * crouch;
      return {
        hip: P(0, rise),
        lean: -0.05 + crouch * 0.18 - flight * 0.1,
        headTilt: -0.2 * flight,
        hands: [
          P(-19 - 4 * flight, -50 + 14 * crouch - 46 * flight - 6 * settle),
          P(19 + 4 * flight, -51 + 14 * crouch - 46 * flight - 6 * settle)
        ],
        feet: [
          P(-16 - 3 * crouch, 40 - 10 * crouch + 8 * flight - 16 * settle),
          P(16 + 3 * crouch, 41 - 10 * crouch + 8 * flight - 16 * settle)
        ]
      };
    },

    /* Falling — flailing limbs, tumbling lean */
    fall(t) {
      const a = t * Math.PI * 2;
      return {
        hip: P(Math.sin(a) * 3, 0),
        lean: Math.sin(a * 0.5) * 0.35,
        headTilt: 0.25,
        hands: [P(-30 + Math.sin(a) * 10, -40 + Math.cos(a) * 16),
                P(30 - Math.sin(a + 1) * 10, -42 - Math.cos(a) * 14)],
        feet: [P(-22 - Math.cos(a) * 8, 38 + Math.sin(a) * 8),
               P(22 + Math.cos(a + 1) * 8, 36 - Math.sin(a) * 8)]
      };
    },

    /* Rest / shake-out — one arm hangs and shakes blood back */
    rest(t) {
      const sh = Math.sin(t * Math.PI * 8) * (t > 0.2 && t < 0.8 ? 1 : 0);
      const drop = win(t, 0.05, 0.25) - win(t, 0.78, 0.98);
      const b = Math.sin(t * Math.PI * 2);
      return {
        hip: P(6 * drop, 6 + b * 1.5),
        lean: 0.12 * drop,
        headTilt: -0.1,
        hands: [P(-18 - 4 * drop, -52 + 2 * b),
                P(18 + 16 * drop + sh * 5, -52 + 58 * drop + sh * 3)],
        feet: [P(-16, 40), P(17, 41)]
      };
    },

    /* Slipping on ice — feet skate, hands scrabble, body sinks */
    slip(t) {
      const sink = t * 18;
      const sc = Math.sin(t * Math.PI * 6);
      return {
        hip: P(sc * 2, sink),
        lean: 0.05 + sc * 0.05,
        headTilt: -0.15,
        hands: [P(-21 + sc * 3, -50 + sink * 0.35 + sc * 2),
                P(21 - sc * 3, -51 + sink * 0.35 - sc * 2)],
        feet: [P(-18 - t * 8 + sc * 3, 42 + sink * 0.5),
               P(18 + t * 8 - sc * 3, 43 + sink * 0.5)]
      };
    },

    /* Mantle / top-out — press over the ledge */
    mantle(t) {
      const press = smooth(clamp(t / 0.6, 0, 1));
      const step = smooth(clamp((t - 0.45) / 0.4, 0, 1));
      const stand = smooth(clamp((t - 0.7) / 0.3, 0, 1));
      return {
        hip: P(6 * press + 10 * stand, -8 - 52 * press - 18 * stand),
        lean: 0.35 * press - 0.3 * stand,
        headTilt: -0.15 + 0.2 * stand,
        hands: [P(-20 + 6 * press, -50 + 44 * press - 12 * stand),
                P(22 + 6 * press, -50 + 44 * press - 12 * stand)],
        feet: [P(-18 + 20 * step, 44 - 30 * step + 10 * stand),
               P(18 + 6 * step, 44 - 4 * step + 8 * stand)]
      };
    },

    /* Victory at the summit — arms up, small hop */
    victory(t) {
      const hop = Math.abs(Math.sin(t * Math.PI * 2));
      return {
        hip: P(0, -10 * hop),
        lean: 0,
        headTilt: 0.05 * Math.sin(t * Math.PI * 4),
        hands: [P(-30, -62 - 6 * hop), P(30, -62 - 6 * hop)],
        feet: [P(-14, 42 - 4 * hop), P(14, 42 - 4 * hop)]
      };
    },

    /* Overhang / roof — body horizontal-ish, heel hook */
    overhang(t) {
      const c = Math.sin(t * Math.PI * 2);
      const pull = win(t, 0.1, 0.5) - win(t, 0.55, 0.95);
      return {
        hip: P(-6 * pull, 4 - 8 * pull),
        lean: 0.45 + 0.12 * pull,
        headTilt: -0.3,
        hands: [P(-24, -44 + 6 * pull), P(16, -50 + 6 * pull)],
        feet: [P(-30 - 6 * c, 26 - 10 * pull), P(24, 40 - 6 * pull)]
      };
    },

    /* Chimney / crack — pressing between two walls */
    chimney(t) {
      const push = Math.sin(t * Math.PI * 2);
      const up = -10 * (0.5 + 0.5 * Math.sin(t * Math.PI * 2 - 1.5));
      return {
        hip: P(0, up),
        lean: -0.05,
        headTilt: -0.05,
        hands: [P(-34, -30 + push * 6), P(34, -34 - push * 6)],
        feet: [P(-34, 34 - push * 6), P(34, 30 + push * 6)]
      };
    }
  };

  // fix climbUp right-hand expression (keep it simple & correct)
  anims.climbUp = function (t) {
    const H = 46;
    const sway = Math.sin(t * Math.PI * 4) * 3;
    const lh = win(t, 0.00, 0.22), rf = win(t, 0.24, 0.46),
          rh = win(t, 0.50, 0.72), lf = win(t, 0.74, 0.96);
    const arc = (u, h) => -Math.sin(u * Math.PI) * h;
    return {
      hip: P(sway * 0.5, -H * t),
      lean: sway * 0.012,
      headTilt: -0.12,
      hands: [P(-20 + arc(lh, 5), -54 - H * lh + arc(lh, 10)),
              P(20 - arc(rh, 5), -55 - H * rh + arc(rh, 10))],
      feet: [P(-16, 40 - H * lf + arc(lf, 8)),
             P(16, 41 - H * rf + arc(rf, 8))]
    };
  };

  /* Linear root displacement over one cycle (for in-place looping / engine hookup) */
  const ROOT = {
    climbUp:  { x: 0,  y: -46 },
    traverse: { x: 40, y: 0 },
    slip:     { x: 0,  y: 18 },
    dyno:     { x: 0,  y: -68 },
    mantle:   { x: 16, y: -78 }
  };
  const ONESHOT = ['dyno', 'mantle', 'slip'];

  const META = [
    ['idle',     'Hang / Idle',     'Resting on two holds, breathing sway. Default loop.', 'loop'],
    ['climbUp',  'Climb Up',        '4-beat ladder cycle: hand, foot, hand, foot.', 'loop'],
    ['traverse', 'Traverse',        'Sideways shuffle along a line of holds.', 'loop'],
    ['dyno',     'Dyno Jump',       'Crouch, explode, latch the far hold.', 'one-shot'],
    ['fall',     'Fall',            'Flailing tumble after a blown grip.', 'loop'],
    ['rest',     'Shake Out',       'One arm drops and shakes the pump out.', 'loop'],
    ['slip',     'Slip (Ice)',      'Feet skate off, body sinks — used on ice walls.', 'one-shot'],
    ['mantle',   'Mantle / Top-out','Press over the lip and stand up.', 'one-shot'],
    ['victory',  'Summit',          'Arms up celebration hop.', 'loop'],
    ['overhang', 'Overhang Pull',   'Roof climbing with a heel hook.', 'loop'],
    ['chimney',  'Chimney Press',   'Stemming between two opposing walls.', 'loop']
  ];

  /* Sample an animation into a world-space pose at (ox,oy).
     opts.inPlace (default true) removes root translation so the loop cycles on the spot;
     opts.hold eases one-shots by holding the final pose for the tail of the cycle.     */
  function sample(name, t, ox, oy, flip, opts) {
    opts = opts || {};
    let u = ((t % 1) + 1) % 1;
    const oneShot = ONESHOT.indexOf(name) >= 0;
    if (opts.hold !== false && oneShot) u = clamp(u / 0.85, 0, 1);
    const s = anims[name](u);
    if (opts.inPlace !== false && ROOT[name]) {
      const r = ROOT[name], k = oneShot ? u : u;
      const sub = p => ({ x: p.x - r.x * k, y: p.y - r.y * k });
      s.hip = sub(s.hip);
      s.hands = s.hands.map(sub);
      s.feet = s.feet.map(sub);
    }
    const f = flip ? -1 : 1;
    const m = p => ({ x: ox + p.x * f, y: oy + p.y });
    return buildPose({
      hip: m(s.hip),
      lean: (s.lean || 0) * f,
      headTilt: (s.headTilt || 0) * f,
      hands: s.hands.map(m),
      feet: s.feet.map(m)
    });
  }

  return { L, lerp, clamp, smooth, win, ik, buildPose, draw, anims, META, sample, REST, ROOT, ONESHOT };
})();

if (typeof module !== 'undefined') module.exports = STICK;
